//package org.green.service;
//
//import java.util.List;
//
//import org.green.domain.Criteria;
//import org.green.domain.GalleryBoardDTO;
//
//public interface GalleryBoardService {
//	//등록 insert	
//	public void galleryRegister(GalleryBoardDTO gboard);
//	//게시글 1개 조회 select
//	public GalleryBoardDTO galleryGet(Long gno);
//	//수정하기 
//	public boolean galleryModify(GalleryBoardDTO gboard);
//	//삭제하기
//	public boolean galleryRemove(Long gno);
//	//게시글 목록 조회 
//	public List<GalleryBoardDTO> getGalleryList(Criteria cri);
//	//게시글 개수 조회 
//	public int getGalleryTotal(Criteria cri);
//	
//	public List<GalleryBoardDTO> getGalleryList(Long bno);
//}
