package org.green.mapper;

public interface TimeMapper {
	public String getTime();
}
