package org.manager.domain;

import java.util.Date;

import lombok.Data;

@Data
public class DaySalesVO {
	private Long daysales;
	private Date postdate;
}
