package org.manager.mapper;

import org.manager.domain.AuthVO;

public interface MemberAuthMapper {
	public void Ainsert (AuthVO avo);
}
