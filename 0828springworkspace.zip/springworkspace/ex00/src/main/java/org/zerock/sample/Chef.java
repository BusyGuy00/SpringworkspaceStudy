package org.zerock.sample;

import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.ToString;

@Component
@ToString
@Data
public class Chef {

}
