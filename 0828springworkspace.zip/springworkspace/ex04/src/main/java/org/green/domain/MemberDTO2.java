package org.green.domain;

import lombok.Data;

@Data
public class MemberDTO2 {
	private String userid;
	private String passwd;
	private String birthyear;
}
