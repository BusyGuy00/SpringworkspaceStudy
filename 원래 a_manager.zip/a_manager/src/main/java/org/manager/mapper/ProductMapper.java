package org.manager.mapper;

import java.util.List;

import org.manager.domain.ProductDTO;

public interface ProductMapper {
	
	//제품 리스트 
	public List<ProductDTO> getList();
	
	//상품 insert
	public void insert (ProductDTO pto);
	
	//select
	public ProductDTO read(int pno);
	
	//update
	public int update (ProductDTO pto);
	
	//delete
	public int delete (int pno);
}
