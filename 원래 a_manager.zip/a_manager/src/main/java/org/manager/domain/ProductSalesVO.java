package org.manager.domain;

import java.util.Date;

import lombok.Data;

@Data
public class ProductSalesVO {
	private String pno;
	private String daysales;
	private String pricesales;
	private String priceCount;
	private String weeksales;
	private String monthsales;
	private String yearsales;
	private String writer;
	private Date postdate;
	private String pname;
	private String category;
}
