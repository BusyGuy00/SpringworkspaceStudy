package org.manager.controller;

public class DaySalesController {

}
