package org.manager.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.manager.domain.ProductDTO;
import org.manager.domain.ProductSalesVO;
import org.manager.service.ProductSalesService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@RequestMapping("sale/*")
@AllArgsConstructor
public class ProductSalesController {
	private ProductSalesService service;
	
	@GetMapping("/saleinsert")
	public void saleList(Model model, ProductDTO pto) {
		log.info("확인용1 : "+pto);
		model.addAttribute("list", service.daysale(pto));
	}
	@PostMapping("/saleinsert")
	public String saleinsert (
			RedirectAttributes rttr,
			ProductSalesVO pvo,
			@RequestParam("pname") List<String> pnames,
			@RequestParam("writer") List<String> writers,
			@RequestParam("category") List<String> categorys,
			@RequestParam("priceCount") List<String> priceCounts,
			@RequestParam("pricesales") List<String> pricesales

			) {
			for (int i = 0; i < pnames.size(); i++) {
			pvo.setPname(pnames.get(i));
			pvo.setWriter(writers.get(i));
			pvo.setCategory(categorys.get(i));
			pvo.setPriceCount(priceCounts.get(i));
			pvo.setPricesales(pricesales.get(i));

			//pvo.setCategory(categories.get(i));

			service.dayinsert(pvo);
			log.info("==================================================");
			log.info("확인용2 : "+pvo);
			log.info("==================================================");
			rttr.addAttribute("result",pvo.getPno());
			//rttr.addAttribute("result","등록");
	
			}
			return "redirect:../product/list";
	}
}
	

