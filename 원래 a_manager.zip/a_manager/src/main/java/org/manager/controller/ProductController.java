package org.manager.controller;

import org.manager.domain.ProductDTO;
import org.manager.domain.ProductSalesVO;
import org.manager.service.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@RequestMapping("product/*")
@AllArgsConstructor
public class ProductController {
	private ProductService service;
	
	@GetMapping("/list")
	public void list(Model model, ProductDTO pdto)  {
		model.addAttribute("list", service.getList(pdto ));

	}
	@GetMapping("/insert")
	public void insert() {
	}
	@PostMapping("/insert")
	public String postinsert(ProductDTO pdto, RedirectAttributes rttr)
	{
		log.info("==================================================");
		log.info("register : " + pdto);
		log.info("==================================================");
		service.insert(pdto);
		//보내는 메소드
		rttr.addAttribute("result",pdto.getPno());
		//rttr.addAttribute("result","등록");
		return "redirect:/product/list";
	}
	//게시글 상세 보기 
	//게시글 조회 상세보기 + 수정하기 페이지 추가 
	@GetMapping({"/view","/modify"})
	public void get(int pno, Model model) {
		model.addAttribute("board",service.read(pno));
	}
	
	
	
	
	
}
