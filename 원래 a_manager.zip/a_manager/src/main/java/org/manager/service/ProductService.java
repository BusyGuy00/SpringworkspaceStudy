package org.manager.service;

import java.util.List;

import org.manager.domain.ProductDTO;
import org.manager.domain.ProductSalesVO;

public interface ProductService {
	//리스트
	public List<ProductDTO> getList(ProductDTO pto);
	//등록
	public void insert (ProductDTO pto);
	//상세보기 
	public ProductDTO read(int pno);
	//게시글 수정
	public boolean update(ProductDTO pto);
	//삭제하기 
	public boolean delete(int pno);
	

	
	
	
}
